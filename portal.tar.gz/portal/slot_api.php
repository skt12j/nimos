<?php
// portal/slot_api.php - OPENWRT RAM-DISK EDITION (Hardware Protector)
require_once '../core.php';

// ==========================================
// 🎯 HARDWARE TARGET & SECURITY
// ==========================================
$saved_ip = pullFromVault('esp_ip.txt');
$ESP_IP = !empty($saved_ip) ? trim($saved_ip) : "192.168.1.10"; 

$saved_key = pullFromVault('master_key.txt');
$SECRET_TOKEN = !empty($saved_key) ? trim($saved_key) : "111625080052";   

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

$client_ip = $_SERVER['REMOTE_ADDR'];
$client_mac = getClientMac($client_ip);
$action = $_POST['action'] ?? $_GET['action'] ?? 'status';

// 🔥 OPENWRT HARDWARE FIX: Route temporary files to RAM disk so they don't destroy flash memory! 🔥
$lock_file = '/tmp/slot_lock.json';
$buffer_file = '/tmp/coin_buffer.txt';
$debug_file = '/tmp/coin_debug.txt'; 

$data = file_exists($lock_file) ? json_decode(file_get_contents($lock_file), true) : [
    'mac' => null, 
    'expires' => 0
];
$now = time();

// Fetch current coins immediately to use in failsafes
$current_buffer = (int)@file_get_contents($buffer_file); 

function triggerHardware($command) {
    global $ESP_IP, $SECRET_TOKEN;
    $separator = (strpos($command, '?') !== false) ? '&' : '?';
    $url = "http://{$ESP_IP}/{$command}{$separator}token={$SECRET_TOKEN}";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2); 
    curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($http_code == 200);
}

// ==========================================
// 💥 ACTION: ABANDON (User refreshed/closed tab)
// ==========================================
if ($action === 'abandon') {
    if ($data['mac'] === $client_mac) {
        $data['expires'] = $now - 5; 
        file_put_contents($lock_file, json_encode($data), LOCK_EX);
    }
    exit(json_encode(['status' => 'held']));
}

// ==========================================
// 🛡️ BROWNOUT & TIMEOUT RECOVERY (ZOMBIE CATCHER)
// ==========================================
if ($data['mac'] !== null && $data['expires'] > 0 && $now > $data['expires']) {
    triggerHardware("close");
    
    if ($current_buffer > 0) {
        $mac_to_credit = $data['mac'];
        $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
        
        if (!isset($sessions[$mac_to_credit])) {
             $sessions[$mac_to_credit] = [
                'ip' => '0.0.0.0',
                'tier' => 'Regular',
                'status' => 'paused',
                'active_mode' => 'Time',
                'expires' => 0,
                'time_left' => 0
             ];
        }
        
        $current_pending = isset($sessions[$mac_to_credit]['pending_coins']) ? (int)$sessions[$mac_to_credit]['pending_coins'] : 0;
        $sessions[$mac_to_credit]['pending_coins'] = $current_pending + $current_buffer;
        
        $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
        $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $mac_to_credit, 'event' => 'ZOMBIE_HELD', 'details' => "₱$current_buffer safely held."];
        
        pushToVault('sessions.json', json_encode($sessions)); 
        pushToVault('logs.json', json_encode($logs)); 
    }
    
    $data['mac'] = null;
    $data['expires'] = 0;
    file_put_contents($lock_file, json_encode($data), LOCK_EX);
    file_put_contents($buffer_file, '0', LOCK_EX);
    $current_buffer = 0;
}

// ==========================================
// 🟢 ACTION: RESUME PENDING RECOVERY
// ==========================================
if ($action === 'resume_pending') {
    $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
    
    if (isset($sessions[$client_mac]) && isset($sessions[$client_mac]['pending_coins'])) {
        $recovered_coins = (int)$sessions[$client_mac]['pending_coins'];
        
        file_put_contents($buffer_file, (string)$recovered_coins, LOCK_EX);
        
        $data['mac'] = $client_mac;
        $data['expires'] = $now + 30;
        file_put_contents($lock_file, json_encode($data), LOCK_EX);
        
        unset($sessions[$client_mac]['pending_coins']);
        pushToVault('sessions.json', json_encode($sessions));
        
        triggerHardware("open?coins=" . $recovered_coins);
        
        exit(json_encode([
            'status' => 'success', 
            'recovered_coins' => $recovered_coins, 
            'msg' => 'Coins successfully recovered!'
        ]));
    }
    exit(json_encode(['status' => 'error', 'msg' => 'No pending coins found to recover.']));
}

// ==========================================
// 🗑️ ACTION: DISCARD PENDING RECOVERY
// ==========================================
if ($action === 'discard_pending') {
    $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
    if (isset($sessions[$client_mac]) && isset($sessions[$client_mac]['pending_coins'])) {
        unset($sessions[$client_mac]['pending_coins']);
        pushToVault('sessions.json', json_encode($sessions));
        exit(json_encode(['status' => 'success']));
    }
    exit(json_encode(['status' => 'ignored']));
}

if ($action === 'check') { exit(json_encode(['status' => 'success', 'coins' => $current_buffer])); }

// ==========================================
// 🪙 ACTION: RECEIVE COIN (FROM ESP32)
// ==========================================
if ($action === 'insert_coin_api' || $action === 'pulse') {
    $incoming_coins = (int)($_POST['coins'] ?? $_GET['coins'] ?? $_POST['pulses'] ?? 0);
    $incoming_token = $_POST['token'] ?? $_GET['token'] ?? '';
    
    $log_msg = "[" . date('H:i:s') . "] ESP32 Sent: $incoming_coins coins. Token: '$incoming_token'. ";

    if ($incoming_token !== $SECRET_TOKEN && !empty($_POST['token'])) {
        file_put_contents($debug_file, $log_msg . "FAILED: Bad Token Mismatch!\n", FILE_APPEND);
        die(json_encode(["status" => "error", "msg" => "Bad Token"]));
    }
    
    if ($data['mac'] !== null) {
        $new_total = $current_buffer + $incoming_coins;
        file_put_contents($buffer_file, (string)$new_total, LOCK_EX);
        $data['expires'] = $now + 30; 
        file_put_contents($lock_file, json_encode($data), LOCK_EX);
        
        file_put_contents($debug_file, $log_msg . "SUCCESS: Added to MAC " . $data['mac'] . ". Total Buffer: $new_total\n", FILE_APPEND);
        exit(json_encode(['status' => 'success']));
    }
    
    file_put_contents($debug_file, $log_msg . "IGNORED: Slot not locked by any phone.\n", FILE_APPEND);
    exit(json_encode(['status' => 'ignored']));
}

// ==========================================
// 🔒 ACTION: LOCK
// ==========================================
if ($action === 'lock') {
    $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
    
    if (isset($sessions[$client_mac]['pending_coins']) && $sessions[$client_mac]['pending_coins'] > 0) {
        $stuck = $sessions[$client_mac]['pending_coins'];
        exit(json_encode(['status' => 'pending_choice', 'buffered_coins' => $stuck]));
    }

    if ($data['mac'] === $client_mac) {
        $data['expires'] = $now + 30;
        file_put_contents($lock_file, json_encode($data), LOCK_EX);
        triggerHardware("open?coins=" . $current_buffer);
        exit(json_encode(['status' => 'success', 'expires_in' => 30, 'msg' => 'Session Resumed!', 'buffered_coins' => $current_buffer]));
    }

    if ($data['mac'] !== null) exit(json_encode(['status' => 'error', 'msg' => 'SYSTEM BUSY.']));

    $hardware_online = triggerHardware("open");
    if (!$hardware_online) exit(json_encode(['status' => 'error', 'msg' => "HARDWARE OFFLINE."]));

    file_put_contents($buffer_file, '0', LOCK_EX);
    $data['mac'] = $client_mac;
    $data['expires'] = $now + 30; 
    file_put_contents($lock_file, json_encode($data), LOCK_EX);
    exit(json_encode(['status' => 'success', 'expires_in' => 30]));
}

if ($action === 'release') {
    if ($data['mac'] === $client_mac) {
        $data['mac'] = null; $data['expires'] = 0;
        file_put_contents($lock_file, json_encode($data), LOCK_EX);
        triggerHardware("close");
    }
    exit(json_encode(['status' => 'released']));
}

$is_online = triggerHardware("ping");
$data['esp_status'] = $is_online ? 'ONLINE' : 'OFFLINE';
echo json_encode($data);
?>